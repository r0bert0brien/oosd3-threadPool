import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

//Author: Robert O'Brien
//Student Number: C20436696
//Publish Date: 05/05/2022

public class ThreadPool {

	static boolean endOfFile = false;//Flag to Signify the Program is over
	public static void main(String[] args) {
		ExecutorService executor = Executors.newFixedThreadPool(2);//Specifying the Size of the Thread Pool
		Reader reader;
		File file = new File("javaFile.txt");//New File to Write to for Memory
		try {
			if(file.createNewFile()) {//Checking to see if the File has already been Created
				System.out.println("New File Created");
			}else {
				System.out.println("File already exists");
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Writer writer;
		try {
			writer = new FileWriter("javaFile.txt");//Specifying the File to Write to 
			BufferedWriter bufferWrite = new BufferedWriter(writer);//Creating the Buffered Writer
			reader = new FileReader("words.txt");//Specifying the File to Read from 
			BufferedReader buffer = new BufferedReader(reader);//Creating the Buffered Reader
			while (endOfFile != true) {//While the Reader isnt at the end of the file, run the threads 
				Runnable worker = new WorkerThread(buffer, bufferWrite);
				executor.execute(worker);
			}
			buffer.close();//When done, close the BufferedReader, Buffered Writer, FileReader and File Writer
			bufferWrite.close();
			reader.close();
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		executor.shutdown();//Shutting down the Executor Service 
		while (!executor.isTerminated()) {
		}
		System.out.println("Finished all threads");//Notifying the User the Executor Service is over

	}
}

class WorkerThread implements Runnable{
	ThreadPool p;
	BufferedReader buffer;//Creating instances of ThreadPool's BufferedReader and Writer
	BufferedWriter bufferWrite;
	public WorkerThread(BufferedReader buffer, BufferedWriter bufferWrite) {
		this.buffer = buffer;
		this.bufferWrite = bufferWrite;
	}
	public void run() {
		System.out.println("Running...");//Notify the User the Threads are Running
		synchronized(buffer) {//Synchronized Block
			try {
				String data = buffer.readLine();//Reading the Line of the Data
				if (data != null) {//If the Line isnt Null, Sleep for 1000ms, Write to the new File, Move the BufferedWriter to a new file and Flush the BufferedWriter
					Thread.sleep(1000);
					bufferWrite.write(data);
					bufferWrite.newLine();
					bufferWrite.flush();
					
				}else {
					ThreadPool.endOfFile = true;//Signify the end of the Program
				}
			} catch (IOException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}
}